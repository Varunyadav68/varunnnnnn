const API_URL = "https://dummyjson.com/users";


let students = [];
let toastTimer;

function loadStudents(){
  try {
    const saved = localStorage.getItem("studentPortalRecords");
    return saved ? JSON.parse(saved) : starterStudents;
  } catch { return starterStudents; }
}
function mapApiStudent(user){
  const gender = user.gender ? user.gender.charAt(0).toUpperCase()+user.gender.slice(1) : "Other";
  return {id:user.id,name:user.name||`${user.firstName||""} ${user.lastName||""}`.trim(),phone:user.phone||"",email:user.email||"",gender,course:user.company?.title||"Other",dob:user.birthDate||""};
}
async function fetchStudents(){
  try {
    const response=await fetch(`${API_URL}?limit=15`);
    if(!response.ok)throw new Error("Unable to load students");
    students=(await response.json()).users.map(mapApiStudent);
    persist();
    showToast("Students loaded from API.");
  } catch {
    students=loadStudents();
    showToast("API unavailable. Showing saved students.");
  }
  renderDashboard();renderStudents();
}
async function apiRequest(method, student, id=""){
  const payload={firstName:student.name.split(" ")[0],lastName:student.name.split(" ").slice(1).join(" "),email:student.email,phone:student.phone,gender:student.gender.toLowerCase(),birthDate:student.dob,company:{title:student.course}};
  const response=await fetch(`${API_URL}${id?`/${id}`:"/add"}`,{method,headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
  if(!response.ok)throw new Error("API request failed");
  return mapApiStudent(await response.json());
}
async function deleteFromApi(id){
  const response=await fetch(`${API_URL}/${id}`,{method:"DELETE"});
  if(!response.ok)throw new Error("API request failed");
}
function persist(){ localStorage.setItem("studentPortalRecords", JSON.stringify(students)); }
function escapeHTML(value=""){
  return String(value).replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
}
function showToast(message){
  const toast = document.getElementById("toast");
  toast.textContent = message; toast.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(()=>toast.classList.remove("show"),2600);
}
function goTo(page){
  document.querySelectorAll(".page").forEach(el=>el.classList.toggle("active",el.id===`page-${page}`));
  document.querySelectorAll(".nav-link").forEach(el=>el.classList.toggle("active",el.dataset.page===page));
  const titles={dashboard:"Student Dashboard",add:document.getElementById("student-id").value?"Update Student":"Add New Student",students:"Students List",search:"Search Student"};
  document.getElementById("page-heading").textContent=titles[page]||"Student Portal";
  if(page==="dashboard") renderDashboard();
  if(page==="students") renderStudents();
  if(page==="search") document.getElementById("search-input").focus();
}
function renderDashboard(){
  document.getElementById("total-count").textContent=students.length;
  document.getElementById("active-count").textContent=students.length;
  document.getElementById("male-count").textContent=students.filter(s=>s.gender==="Male").length;
  document.getElementById("female-count").textContent=students.filter(s=>s.gender==="Female").length;
  const rows=students.slice(-5).reverse();
  document.getElementById("recent-table").innerHTML=rows.length?rows.map(s=>`<tr><td>${s.id}</td><td><strong>${escapeHTML(s.name)}</strong></td><td>${escapeHTML(s.course)}</td><td>${escapeHTML(s.email)}</td><td><span class="status">Active</span></td></tr>`).join(""):`<tr><td colspan="5">No student records yet.</td></tr>`;
}
function renderStudents(){
  const filter=document.getElementById("list-filter").value.trim().toLowerCase();
  const list=students.filter(s=>[s.name,s.email,s.course,s.gender].some(v=>(v||"").toLowerCase().includes(filter)));
  document.getElementById("list-count").textContent=`${list.length} student${list.length===1?"":"s"}`;
  document.getElementById("empty-students").classList.toggle("hidden",list.length!==0);
  document.getElementById("students-table").innerHTML=list.map(s=>`<tr><td>${s.id}</td><td><strong>${escapeHTML(s.name)}</strong></td><td>${escapeHTML(s.course)}</td><td>${escapeHTML(s.email)}</td><td>${escapeHTML(s.gender)}</td><td>${escapeHTML(s.phone||"—")}</td><td><div class="actions"><button class="small-btn edit-btn" data-edit="${s.id}">Edit</button><button class="small-btn delete-btn" data-delete="${s.id}">Delete</button></div></td></tr>`).join("");
}
function clearForm(){
  document.getElementById("student-form").reset();
  document.getElementById("student-id").value="";
  document.getElementById("form-heading").textContent="Add New Student";
  document.getElementById("save-btn").textContent="Save Student";
  document.getElementById("cancel-edit").classList.add("hidden");
  document.getElementById("page-heading").textContent="Add New Student";
}
function editStudent(id){
  const s=students.find(item=>item.id===Number(id)); if(!s)return;
  document.getElementById("student-id").value=s.id;
  ["name","phone","email","gender","course","dob"].forEach(key=>document.getElementById(key).value=s[key]||"");
  document.getElementById("form-heading").textContent="Update Student";
  document.getElementById("save-btn").textContent="Update Student";
  document.getElementById("cancel-edit").classList.remove("hidden");
  goTo("add");
  document.getElementById("page-heading").textContent="Update Student";
}
async function deleteStudent(id){
  const s=students.find(item=>item.id===Number(id)); if(!s)return;
  if(!confirm(`Delete ${s.name}'s record? This cannot be undone.`))return;
  try { await deleteFromApi(id); } catch { showToast("Could not delete student from API.");return; }
  students=students.filter(item=>item.id!==Number(id));persist();renderStudents();renderDashboard();showToast("Student deleted successfully.");
}
function renderSearch(query){
  const q=query.trim().toLowerCase(), target=document.getElementById("search-results");
  if(!q){target.innerHTML='<div class="search-placeholder">Enter a name or email above to search student records.</div>';return;}
  const results=students.filter(s=>s.name.toLowerCase().includes(q)||s.email.toLowerCase().includes(q));
  if(!results.length){target.innerHTML='<div class="search-placeholder">No students match your search. Try another name or email.</div>';return;}
  target.innerHTML=results.map(s=>`<article class="student-result"><div class="avatar">♟</div><div class="result-details"><strong>Name</strong><span>${escapeHTML(s.name)}</span><strong>Email</strong><span>${escapeHTML(s.email)}</span><strong>Course</strong><span>${escapeHTML(s.course)}</span><strong>Gender</strong><span>${escapeHTML(s.gender)}</span><strong>Phone Number</strong><span>${escapeHTML(s.phone||"Not provided")}</span>${s.dob?`<strong>Date of Birth</strong><span>${escapeHTML(s.dob)}</span>`:""}</div></article>`).join("");
}

document.querySelectorAll(".nav-link").forEach(btn=>btn.addEventListener("click",()=>goTo(btn.dataset.page)));
document.querySelectorAll("[data-go]").forEach(btn=>btn.addEventListener("click",()=>{clearForm();goTo(btn.dataset.go)}));
document.getElementById("header-add").addEventListener("click",()=>{clearForm();goTo("add")});
document.getElementById("student-form").addEventListener("submit",async event=>{
  event.preventDefault();
  const id=Number(document.getElementById("student-id").value);
  const record={name:document.getElementById("name").value.trim(),phone:document.getElementById("phone").value.trim(),email:document.getElementById("email").value.trim(),gender:document.getElementById("gender").value,course:document.getElementById("course").value,dob:document.getElementById("dob").value};
  if(!record.name||!record.email||!record.gender||!record.course)return;
  const duplicate=students.find(s=>s.email.toLowerCase()===record.email.toLowerCase()&&s.id!==id);
  if(duplicate){showToast("A student with this email already exists.");document.getElementById("email").focus();return;}
  try {
    const saved=await apiRequest(id?"PUT":"POST",record,id);
    if(id){students=students.map(s=>s.id===id?{...saved,id}:s);showToast("Student updated successfully.");}
    else{students.push(saved);showToast("Student added successfully.");}
  } catch { showToast("Could not save student to API.");return; }
  persist();clearForm();renderDashboard();renderStudents();goTo("students");
});
document.getElementById("reset-btn").addEventListener("click",()=>setTimeout(()=>{if(!document.getElementById("student-id").value)showToast("Form reset.");},0));
document.getElementById("cancel-edit").addEventListener("click",()=>{clearForm();goTo("students")});
document.getElementById("list-filter").addEventListener("input",renderStudents);
document.getElementById("students-table").addEventListener("click",event=>{
  const edit=event.target.closest("[data-edit]"), del=event.target.closest("[data-delete]");
  if(edit)editStudent(edit.dataset.edit); if(del)deleteStudent(del.dataset.delete);
});
document.getElementById("search-form").addEventListener("submit",event=>{event.preventDefault();renderSearch(document.getElementById("search-input").value)});
document.getElementById("search-input").addEventListener("input",event=>renderSearch(event.target.value));
document.getElementById("year").textContent=new Date().getFullYear();
fetchStudents();
